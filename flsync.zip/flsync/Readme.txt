Welcome to Flsync Desktop application
When you will create your account 
we will create for you a new folder inside this folder with your username
This folder will be the synchronization folder 
Everthing in this folder will synchronizate